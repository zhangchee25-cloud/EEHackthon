import React from 'react';
import ReactDOM from 'react-dom/client';
import Site from './Site';
import './tokens.css';
import './ui.css';
import './styles.css';
import './landing.css';
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><Site /></React.StrictMode>);
